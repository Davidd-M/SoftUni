from django.test import TestCase
from main_app.models import MaskedCreditCardField, CreditCard

# Create your tests here.
