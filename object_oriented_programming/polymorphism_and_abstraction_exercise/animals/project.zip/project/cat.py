from project.animal import Animal


class Cat(Animal):

    @staticmethod
    def make_sound():
        return "Meow meow!"
